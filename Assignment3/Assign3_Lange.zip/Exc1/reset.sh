#!/bin/bash
touch one.txt
rm one.txt
touch one.txt
touch two.txt
rm two.txt
touch two.txt
touch three.txt
rm three.txt
touch three.txt

